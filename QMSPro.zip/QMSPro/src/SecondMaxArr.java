import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/smax")
public class SecondMaxArr extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		int arr[] = {12,34,56,10,2,11,89,72};
		int min=arr[0],smin=0;
		for(int i=0;i<arr.length;i++)
		{
			if(min>arr[i]){
				smin=min;
				min=arr[i];
				
			}
			else if(smin>arr[i] && arr[i]!=min)
			{
				smin=arr[i];
			}
		}
		out.println(min + " "+smin);

	}

}
